import ExpertAvailability from "../../components/ExpertAvailability";

export default function AvailabilityPage() {
  return (
    <div className="max-w-7xl mx-auto">
      <ExpertAvailability />
    </div>
  );
}
